"use client";

import { useEffect, useState } from 'react';

interface Doctor { id: string; name: string; specialty?: string }
interface Department { id: string; name: string }
interface Appointment { id: string; date: string; time: string; status: string }

export default function AdminDashboard() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  useEffect(() => {
    const load = async () => {
      const [d1, d2, d3] = await Promise.all([
        fetch('/api/doctors').then(r => r.json()),
        fetch('/api/departments').then(r => r.json()),
        fetch('/api/appointments').then(r => r.json()),
      ]);
      setDoctors(d1.doctors || []);
      setDepartments(d2.departments || []);
      setAppointments(d3.appointments || []);
    };
    load();
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-4 py-24 space-y-12">
      <section>
        <h2 className="text-xl font-medium mb-4">Doctors</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {doctors.map((d) => (
            <div key={d.id} className="bg-white border border-gray-100 rounded-xl p-4">
              <div className="text-sm text-gray-900">{d.name}</div>
              <div className="text-xs text-gray-500">{d.specialty}</div>
            </div>
          ))}
          {doctors.length === 0 && <div className="text-gray-600">No doctors yet.</div>}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-medium mb-4">Departments</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {departments.map((d) => (
            <div key={d.id} className="bg-white border border-gray-100 rounded-xl p-4">
              <div className="text-sm text-gray-900">{d.name}</div>
            </div>
          ))}
          {departments.length === 0 && <div className="text-gray-600">No departments yet.</div>}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-medium mb-4">Appointments</h2>
        <div className="space-y-3">
          {appointments.map((a) => (
            <div key={a.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-center justify-between">
              <div className="text-sm text-gray-900">{a.date} at {a.time}</div>
              <div className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700">{a.status}</div>
            </div>
          ))}
          {appointments.length === 0 && <div className="text-gray-600">No appointments yet.</div>}
        </div>
      </section>
    </div>
  );
}
