"use client";

import { useEffect, useState } from 'react';
import { Icon } from '@iconify/react';
import { useCosmicPayments } from 'cosmic-payments/client';

interface Appointment {
  id: string;
  date: string;
  time: string;
  status: string;
  doctor_id: string;
  patient_id: string;
}

export default function PatientDashboard() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const { getProducts, checkout } = useCosmicPayments();

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch('/api/appointments');
        const data = await res.json();
        setAppointments(data.appointments || []);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handlePay = async () => {
    const products = await getProducts('one-time');
    if (!products || products.length === 0) return;
    const product = products[0];
    const price = product.prices[0];
    if (!price) return;
    await checkout({ priceId: price.price_id, productId: product.product_id, successPath: '/payments/success', cancelPath: '/payments/cancel' });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-24">
      <h1 className="text-2xl font-medium mb-6">Your Appointments</h1>
      {loading ? (
        <div className="text-gray-600">Loading...</div>
      ) : (
        <div className="space-y-4">
          {appointments.map((a) => (
            <div key={a.id} className="bg-white shadow-sm rounded-xl p-4 border border-gray-100 flex items-center justify-between">
              <div>
                <div className="text-gray-900 text-sm">{a.date} at {a.time}</div>
                <div className="text-gray-500 text-xs">Status: {a.status}</div>
              </div>
              <div className="flex items-center gap-2">
                {a.status === 'booked' && (
                  <button
                    onClick={async () => {
                      await fetch(`/api/appointments?id=${a.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'cancelled' }) });
                      setAppointments((prev) => prev.map(x => x.id === a.id ? { ...x, status: 'cancelled' } : x));
                    }}
                    className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-full"
                  >
                    Cancel
                  </button>
                )}
                <button onClick={handlePay} className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-full inline-flex items-center gap-1">
                  <Icon icon="solar:card-linear" /> Pay Bill
                </button>
                <span className="inline-flex items-center gap-1 text-xs text-blue-600">
                  <Icon icon="solar:document-medicine-linear" />
                  Reports
                </span>
              </div>
            </div>
          ))}
          {appointments.length === 0 && (
            <div className="text-gray-600">No appointments yet.</div>
          )}
        </div>
      )}
    </div>
  );
}