"use client";

import { useEffect, useState } from 'react';
import { Icon } from '@iconify/react';

interface Appointment { id: string; date: string; time: string; status: string; patient_id: string; }

export default function DoctorDashboard() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  useEffect(() => {
    const run = async () => {
      const res = await fetch('/api/appointments');
      const data = await res.json();
      setAppointments(data.appointments || []);
    };
    run();
  }, []);

  return (
    <div className="max-w-5xl mx-auto px-4 py-24">
      <h1 className="text-2xl font-medium mb-6">Upcoming Appointments</h1>
      <div className="space-y-4">
        {appointments.map((a) => (
          <div key={a.id} className="bg-white shadow-sm rounded-xl p-4 border border-gray-100 flex items-center justify-between">
            <div>
              <div className="text-gray-900 text-sm">{a.date} at {a.time}</div>
              <div className="text-gray-500 text-xs">Patient: {a.patient_id}</div>
            </div>
            <button className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-full inline-flex items-center gap-1">
              <Icon icon="solar:upload-linear" /> Upload Report
            </button>
          </div>
        ))}
        {appointments.length === 0 && (
          <div className="text-gray-600">No appointments.</div>
        )}
      </div>
    </div>
  );
}
