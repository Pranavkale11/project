import { getServerSession } from 'cosmic-authentication';
import { redirect } from 'next/navigation';
import { db } from 'cosmic-database';

export default async function DashboardRouter() {
  const user = await getServerSession();
  if (!user) {
    return null; // middleware should redirect to sign-in
  }
  const doc = await db.collection('users').doc(user.uid).get();
  const role = (doc.exists ? (doc.data() as { role?: 'patient' | 'doctor' | 'admin' }).role : 'patient') || 'patient';

  if (role === 'admin') redirect('/dashboard/admin');
  if (role === 'doctor') redirect('/dashboard/doctor');
  redirect('/dashboard/patient');
}
