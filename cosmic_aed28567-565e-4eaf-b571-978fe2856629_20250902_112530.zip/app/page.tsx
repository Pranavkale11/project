"use client";

import Navbar from "@/app/components/Navbar";
import HeroSection from "@/app/components/HeroSection";
import FeaturesSection from "@/app/components/FeaturesSection";
import ServicesSection from "@/app/components/ServicesSection";
import HospitalMap from "@/app/components/HospitalMap";
import Footer from "@/app/components/Footer";
import AboutSection from "@/app/components/AboutSection";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <HeroSection />
        <FeaturesSection />
        <ServicesSection />
        <AboutSection />
        <HospitalMap />
      </main>
      <Footer />
    </div>
  );
}