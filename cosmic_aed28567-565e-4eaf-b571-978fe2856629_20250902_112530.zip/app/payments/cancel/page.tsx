export default function CancelPage() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center px-6 text-center">
      <div>
        <h1 className="text-2xl font-medium mb-2">Payment cancelled</h1>
        <p className="text-gray-600">Your payment was cancelled. You can try again anytime.</p>
      </div>
    </div>
  );
}
