export default function SuccessPage() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center px-6 text-center">
      <div>
        <h1 className="text-2xl font-medium mb-2">Payment successful!</h1>
        <p className="text-gray-600">Thank you. Your payment has been processed.</p>
      </div>
    </div>
  );
}
