import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const apiKey = process.env.COSMIC_FILES_SECRET;
    const userId = process.env.USER_ID;
    const projectId = process.env.NEXT_PUBLIC_CLIENT_ID;

    if (!apiKey || !userId || !projectId) {
      return NextResponse.json({ error: 'Files service misconfigured' }, { status: 500 });
    }

    const formData = await request.formData();
    const file = formData.get('file');
    if (!file || !(file instanceof Blob)) {
      return NextResponse.json({ error: 'Missing file' }, { status: 400 });
    }

    const forwardForm = new FormData();
    forwardForm.append('userId', userId);
    forwardForm.append('projectId', projectId);
    forwardForm.append('creatorId', user.uid);
    forwardForm.append('file', file);

    const res = await fetch('https://files.cosmic.new/files/upload', {
      method: 'POST',
      headers: {
        'X-API-Key': apiKey,
      },
      body: forwardForm,
    });

    if (!res.ok) {
      const text = await res.text();
      return NextResponse.json({ error: 'Upload failed', details: text }, { status: 500 });
    }

    const json = await res.json();
    return NextResponse.json(json);
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
