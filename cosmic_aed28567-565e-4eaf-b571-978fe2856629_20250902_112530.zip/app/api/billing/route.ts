import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

type Role = 'patient' | 'doctor' | 'admin';

async function getRole(uid: string): Promise<Role> {
  const doc = await db.collection('users').doc(uid).get();
  const data = doc.exists ? (doc.data() as { role?: Role }) : undefined;
  return data?.role || 'patient';
}

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    const patientId = searchParams.get('patient_id');

    if (id) {
      const doc = await db.collection('billing').doc(id).get();
      if (!doc.exists) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      const data = { id: doc.id, ...doc.data() } as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      if (role !== 'admin' && data.patient_id !== user.uid) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      return NextResponse.json(data);
    }

    if (role === 'admin') {
      if (patientId) {
        const snap = await db.collection('billing').where('patient_id', '==', patientId).limit(100).get();
        const bills = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        return NextResponse.json({ bills });
      }
      const snap = await db.collection('billing').limit(100).get();
      const bills = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      return NextResponse.json({ bills });
    }

    // patient: only theirs
    const snap = await db.collection('billing').where('patient_id', '==', user.uid).limit(100).get();
    const bills = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    return NextResponse.json({ bills });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const data = (await request.json()) as {
      patient_id: string;
      appointment_id?: string;
      amount: number;
      status?: 'paid' | 'pending' | 'cancelled';
      invoice_file?: string | null;
    };

    const payload = {
      ...data,
      status: data.status || 'pending',
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp(),
    };

    const ref = await db.collection('billing').add(payload);
    return NextResponse.json({ success: true, id: ref.id });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    const data = (await request.json()) as Partial<{ amount: number; status: string; invoice_file: string }>;
    await db.collection('billing').doc(id).update({
      ...data,
      updatedAt: db.FieldValue.serverTimestamp(),
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    await db.collection('billing').doc(id).delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}