import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface DoctorDoc {
  name: string;
  specialty: string;
  experience?: number;
  profile_photo?: string | null; // fileId or direct file URL from Cosmic Files GET endpoint
  department_id?: string;
  available_days?: string[]; // e.g., ['Mon','Tue']
  available_times?: string[]; // e.g., ['09:00','10:00']
  createdAt?: unknown;
  updatedAt?: unknown;
}

async function getRole(uid: string): Promise<'patient' | 'doctor' | 'admin'> {
  const doc = await db.collection('users').doc(uid).get();
  const data = doc.exists ? (doc.data() as { role?: 'patient' | 'doctor' | 'admin' }) : undefined;
  return data?.role || 'patient';
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    const departmentId = searchParams.get('department_id');

    if (id) {
      const doc = await db.collection('doctors').doc(id).get();
      if (!doc.exists) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      return NextResponse.json({ id: doc.id, ...doc.data() });
    }

    // Single-field filter (department_id) to avoid composite indexes
    if (departmentId) {
      const snap = await db
        .collection('doctors')
        .where('department_id', '==', departmentId)
        .limit(100)
        .get();
      const doctors = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      return NextResponse.json({ doctors });
    }

    const snapshot = await db.collection('doctors').limit(100).get();
    const doctors = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    return NextResponse.json({ doctors });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const data = (await request.json()) as DoctorDoc;
    const payload: DoctorDoc = {
      ...data,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp(),
    };
    const ref = await db.collection('doctors').add(payload);
    return NextResponse.json({ success: true, id: ref.id });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const data = (await request.json()) as Partial<DoctorDoc>;

    await db.collection('doctors').doc(id).update({
      ...data,
      updatedAt: db.FieldValue.serverTimestamp(),
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    await db.collection('doctors').doc(id).delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}