import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

type Role = 'patient' | 'doctor' | 'admin';

async function getRole(uid: string): Promise<Role> {
  const doc = await db.collection('users').doc(uid).get();
  const data = doc.exists ? (doc.data() as { role?: Role }) : undefined;
  return data?.role || 'patient';
}

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    const doctorId = searchParams.get('doctor_id');
    const patientId = searchParams.get('patient_id');
    const date = searchParams.get('date');

    if (id) {
      const doc = await db.collection('appointments').doc(id).get();
      if (!doc.exists) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      const data = { id: doc.id, ...doc.data() } as Record<string, unknown>;
      // Role-based access
      if (role === 'patient' && data.patient_id !== user.uid) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      if (role === 'doctor' && data.doctor_id !== user.uid) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      return NextResponse.json(data);
    }

    // Restrict non-admins to their own appointments
    let queryField: 'doctor_id' | 'patient_id' | 'date' | null = null;
    let queryValue: string | null = null;

    if (role === 'patient') {
      queryField = 'patient_id';
      queryValue = user.uid;
    } else if (role === 'doctor') {
      queryField = 'doctor_id';
      queryValue = user.uid;
    } else {
      // admin: use provided filter if any
      if (doctorId) { queryField = 'doctor_id'; queryValue = doctorId; }
      else if (patientId) { queryField = 'patient_id'; queryValue = patientId; }
      else if (date) { queryField = 'date'; queryValue = date; }
    }

    let docs;
    if (queryField && queryValue) {
      const snap = await db.collection('appointments').where(queryField, '==', queryValue).limit(100).get();
      docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } else {
      const snap = await db.collection('appointments').limit(100).get();
      docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    }

    // Additional client-side filtering for admin if multiple filters provided
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const filtered = docs.filter((a: any) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const rec = a as any;
      if (doctorId && rec.doctor_id !== doctorId) return false;
      if (patientId && rec.patient_id !== patientId) return false;
      if (date && rec.date !== date) return false;
      return true;
    });

    return NextResponse.json({ appointments: filtered });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);

    const data = (await request.json()) as {
      patient_id: string;
      doctor_id: string;
      date: string;
      time: string;
      status?: 'booked' | 'confirmed' | 'completed' | 'cancelled';
    };

    if (role === 'patient' && data.patient_id !== user.uid) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const payload = {
      ...data,
      status: data.status || 'booked',
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp(),
    };

    const ref = await db.collection('appointments').add(payload);
    return NextResponse.json({ success: true, id: ref.id });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    const data = (await request.json()) as Partial<{ date: string; time: string; status: string }>;

    // Only admin/doctor can change status; patient can cancel their own if still booked
    if (role === 'patient') {
      const doc = await db.collection('appointments').doc(id).get();
      if (!doc.exists) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      const rec = doc.data() as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      if (rec.patient_id !== user.uid) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      if (data.status && data.status !== 'cancelled') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    await db.collection('appointments').doc(id).update({
      ...data,
      updatedAt: db.FieldValue.serverTimestamp(),
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    if (role === 'patient') {
      const doc = await db.collection('appointments').doc(id).get();
      if (!doc.exists) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      const rec = doc.data() as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      if (rec.patient_id !== user.uid) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    await db.collection('appointments').doc(id).delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}