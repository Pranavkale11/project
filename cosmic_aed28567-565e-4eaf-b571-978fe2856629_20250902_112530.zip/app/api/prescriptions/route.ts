import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

type Role = 'patient' | 'doctor' | 'admin';

async function getRole(uid: string): Promise<Role> {
  const doc = await db.collection('users').doc(uid).get();
  const data = doc.exists ? (doc.data() as { role?: Role }) : undefined;
  return data?.role || 'patient';
}

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    const appointmentId = searchParams.get('appointment_id');
    const patientId = searchParams.get('patient_id');

    if (id) {
      const doc = await db.collection('prescriptions').doc(id).get();
      if (!doc.exists) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      const data = { id: doc.id, ...doc.data() } as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      if (role === 'patient' && data.patient_id !== user.uid) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      if (role === 'doctor' && data.doctor_id !== user.uid) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      return NextResponse.json(data);
    }

    let queryField: 'appointment_id' | 'patient_id' | null = null;
    let queryValue: string | null = null;

    if (role === 'patient') {
      queryField = 'patient_id';
      queryValue = user.uid;
    } else if (role === 'doctor') {
      // doctors will typically filter by their own created prescriptions via doctor_id, but to avoid composite indexes, we fetch broadly
      queryField = 'patient_id';
      queryValue = patientId || '';
    } else if (appointmentId) {
      queryField = 'appointment_id';
      queryValue = appointmentId;
    } else if (patientId) {
      queryField = 'patient_id';
      queryValue = patientId;
    }

    let docs;
    if (queryField && queryValue) {
      const snap = await db.collection('prescriptions').where(queryField, '==', queryValue).limit(100).get();
      docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } else {
      const snap = await db.collection('prescriptions').limit(100).get();
      docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    }

    return NextResponse.json({ prescriptions: docs });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role === 'patient') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const data = (await request.json()) as {
      appointment_id: string;
      patient_id: string;
      doctor_id: string;
      fileId?: string | null; // from Cosmic Files (optional)
      notes?: string;
    };

    const payload = {
      ...data,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp(),
    };

    const ref = await db.collection('prescriptions').add(payload);
    return NextResponse.json({ success: true, id: ref.id });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role === 'patient') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    const data = (await request.json()) as Partial<{ fileId: string; notes: string }>;
    await db.collection('prescriptions').doc(id).update({
      ...data,
      updatedAt: db.FieldValue.serverTimestamp(),
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const role = await getRole(user.uid);
    if (role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    await db.collection('prescriptions').doc(id).delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}