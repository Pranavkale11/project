"use client";

import { CosmicAnalytics } from "cosmic-analytics";
import { ReactNode, useEffect } from "react";

interface Props {
  children: ReactNode;
}

export function CosmicAnalyticsProvider({ children }: Props) {
  useEffect(() => {
    // Initialize Cosmic Analytics
    const analytics = new CosmicAnalytics();
    // Check if init method exists before calling it
    if ('init' in analytics && typeof analytics.init === 'function') {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (analytics as any).init();
    }
  }, []);

  return <>{children}</>;
}