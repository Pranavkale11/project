"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Icon } from "@iconify/react";

export default function AboutSection() {
  const ref = useRef<HTMLDivElement | null>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-blue-100/70 text-blue-700 px-4 py-2 rounded-full text-sm font-normal mb-4">
            <Icon icon="mdi:information-outline" className="text-lg" />
            About Wellnest
          </div>
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900">
            How a Hospital Management System Works
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-100 p-8 md:p-10"
        >
          <p className="text-gray-700 leading-relaxed text-base md:text-lg mb-6">
            A Hospital Management System (HMS) is a unified platform that connects all hospital departments so the right people get the right information at the right time. It streamlines patient registration and appointments, maintains electronic health records (EHR), coordinates diagnostics and pharmacy, automates billing and insurance, and supports bed, asset, and staff management—all while keeping data private and secure.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mb-8">
            {[ 
              { title: "Intake", desc: "Online registration, triage, and bed allocation to reduce wait times." },
              { title: "Care Delivery", desc: "Doctors and nurses access EHRs, orders, and notes in one place." },
              { title: "Diagnostics & Pharmacy", desc: "Lab tests, imaging, e‑prescriptions, and stock tracking are coordinated." },
              { title: "Billing & Insurance", desc: "Charges, claims, and approvals are calculated and submitted automatically." },
              { title: "Operations", desc: "Staff scheduling, inventory, and equipment are tracked centrally." },
              { title: "Reporting", desc: "Dashboards show real‑time insights for quality and performance." }
            ].map((item) => (
              <div key={item.title} className="flex items-start gap-3">
                <div className="bg-blue-500/90 text-white rounded-lg p-2 mt-0.5">
                  <Icon icon="solar:check-circle-bold" className="text-base" />
                </div>
                <div>
                  <div className="text-gray-900 font-medium text-sm md:text-base">{item.title}</div>
                  <div className="text-gray-600 text-sm">{item.desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 justify-between">
            <a
              href="https://en.wikipedia.org/wiki/Hospital_information_system"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-blue-700 hover:text-blue-800 font-medium"
            >
              Learn more about Hospital Information Systems
              <Icon icon="solar:arrow-right-linear" className="text-lg" />
            </a>
            <a
              href="#services"
              className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white transition-colors"
            >
              Explore our services
              <Icon icon="solar:compass-linear" className="text-lg" />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
