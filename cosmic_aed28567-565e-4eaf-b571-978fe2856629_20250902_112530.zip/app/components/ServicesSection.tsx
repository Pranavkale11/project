"use client";

import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import { useInView } from "framer-motion";
import { useRef } from "react";

export default function ServicesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const services = [
    {
      icon: "solar:hospital-bold",
      title: "Hospital Management",
      description: "Complete hospital operations management including bed allocation, staff scheduling, and resource optimization.",
      features: ["Bed Management", "Staff Scheduling", "Resource Tracking", "Inventory Control"]
    },
    {
      icon: "solar:user-heart-rounded-linear",
      title: "Patient Care",
      description: "Comprehensive patient management system with medical history, treatment plans, and care coordination.",
      features: ["Medical Records", "Treatment Plans", "Care Coordination", "Patient Portal"]
    },
    {
      icon: "solar:heart-pulse-2-linear",
      title: "Emergency Response",
      description: "Advanced emergency management system with real-time alerts, triage, and critical care coordination.",
      features: ["Real-time Alerts", "Triage System", "Emergency Protocols", "Critical Care"]
    },
    {
      icon: "solar:pills-3-linear",
      title: "Pharmacy Integration",
      description: "Integrated pharmacy management with prescription tracking, drug interactions, and inventory management.",
      features: ["Prescription Management", "Drug Interactions", "Inventory Tracking", "Automated Alerts"]
    }
  ];

  return (
    <section id="services" ref={ref} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-gray-900 mb-6">
            Comprehensive{" "}
            <span className="bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent font-medium">
              Healthcare Solutions
            </span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            From patient admission to discharge, Wellnest provides end-to-end healthcare management 
            solutions designed to enhance patient outcomes and operational efficiency.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="group relative bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 hover:shadow-2xl transition-all duration-500"
            >
              {/* Icon */}
              <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-4 rounded-2xl w-fit mb-6 group-hover:scale-110 transition-transform duration-300">
                <Icon icon={service.icon} className="text-3xl text-white" />
              </div>

              {/* Content */}
              <h3 className="text-2xl font-medium text-gray-900 mb-4">
                {service.title}
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>

              {/* Features */}
              <div className="grid grid-cols-2 gap-3">
                {service.features.map((feature, featureIndex) => (
                  <motion.div
                    key={feature}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
                    transition={{ duration: 0.5, delay: (index * 0.1) + (featureIndex * 0.05) }}
                    className="flex items-center space-x-2"
                  >
                    <div className="bg-blue-500 rounded-full p-1">
                      <Icon icon="solar:check-circle-bold" className="text-xs text-white" />
                    </div>
                    <span className="text-sm text-gray-700 font-medium">{feature}</span>
                  </motion.div>
                ))}
              </div>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/0 to-cyan-500/0 group-hover:from-blue-600/5 group-hover:to-cyan-500/5 transition-all duration-500 rounded-2xl" />
            </motion.div>
          ))}
        </div>

        {/* Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-20 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-2xl p-8 text-white"
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-medium mb-2">Trusted by Healthcare Professionals Worldwide</h3>
            <p className="text-blue-100">Join the growing community of hospitals using Wellnest</p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            {[
              { number: "500+", label: "Hospitals" },
              { number: "50K+", label: "Medical Staff" },
              { number: "2M+", label: "Patients Served" },
              { number: "99.9%", label: "Uptime" }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.5, delay: 0.6 + (index * 0.1) }}
              >
                <div className="text-3xl font-light mb-2">{stat.number}</div>
                <div className="text-blue-100">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}