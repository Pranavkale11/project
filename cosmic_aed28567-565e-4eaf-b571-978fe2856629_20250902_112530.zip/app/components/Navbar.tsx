"use client";

import React, { useState } from "react";
import { Icon } from "@iconify/react";
import { motion } from "framer-motion";
import Link from "next/link";

const menuItems = [
  { name: "Features", href: "#features" },
  { name: "Services", href: "#services" },
  { name: "About", href: "#about" },
  { name: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-blue-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" aria-label="Go to Wellnest home" className="flex items-center space-x-2">
            <div className="bg-blue-500 p-2 rounded-xl">
              <Icon icon="mdi:hospital" className="text-white text-xl" />
            </div>
            <span className="text-xl font-medium text-gray-900">Wellnest</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200"
              >
                {item.name}
              </a>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <button
              onClick={() => {
                const prev = typeof window !== 'undefined' ? localStorage.getItem('lang') || 'en' : 'en';
                const next = prev === 'en' ? 'hi' : 'en';
                if (typeof window !== 'undefined') localStorage.setItem('lang', next);
                alert(`Language set to ${next === 'en' ? 'English' : 'हिंदी'}`);
              }}
              className="px-3 py-1.5 rounded-full border border-gray-200 text-gray-600 hover:text-blue-600 text-sm"
              aria-label="Toggle language"
            >
              EN / हिंदी
            </button>
            <Link href="/dashboard" className="text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200">
              Login
            </Link>
            <Link
              href="/dashboard"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full font-medium transition-colors duration-200"
            >
              Get Started
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Icon
              icon={isMenuOpen ? "mdi:close" : "mdi:menu"}
              className="text-2xl text-gray-600"
            />
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="md:hidden bg-white border-t border-blue-100"
        >
          <div className="px-4 py-4 space-y-3">
            {menuItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="block text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </a>
            ))}
            <div className="pt-4 space-y-3">
              <button
                onClick={() => {
                  const prev = typeof window !== 'undefined' ? localStorage.getItem('lang') || 'en' : 'en';
                  const next = prev === 'en' ? 'hi' : 'en';
                  if (typeof window !== 'undefined') localStorage.setItem('lang', next);
                  alert(`Language set to ${next === 'en' ? 'English' : 'हिंदी'}`);
                }}
                className="block w-full text-left text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200"
              >
                EN / हिंदी
              </button>
              <Link href="/dashboard" className="block w-full text-left text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200">
                Login
              </Link>
              <Link href="/dashboard" className="block w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-full font-medium transition-colors duration-200 text-center">
                Get Started
              </Link>
            </div>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}