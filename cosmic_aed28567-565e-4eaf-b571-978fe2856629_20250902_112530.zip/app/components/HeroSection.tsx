"use client";

import { motion } from "framer-motion";
import { Icon } from "@iconify/react";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-sky-50 to-teal-50">
      {/* Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <div className="inline-flex items-center gap-2 bg-blue-100/80 backdrop-blur-sm text-blue-700 px-4 py-2 rounded-full text-sm font-normal mb-6">
            <Icon icon="solar:hospital-bold" className="text-lg" />
            Next-generation healthcare management
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-light text-gray-900 mb-6 leading-tight">
            Welcome to{" "}
            <span className="bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 bg-clip-text text-transparent font-medium">
              Wellnest
            </span>
          </h1>
          
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto mb-8 leading-relaxed">
            Revolutionize your hospital operations with our comprehensive management platform. 
            Streamline patient care, optimize workflows, and enhance medical outcomes with cutting-edge technology.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
        >
          <a href="/dashboard" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-full font-medium text-base transition-all duration-300 shadow-lg">
            Get Started
          </a>
          
          <a href="#features" className="border border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-3 rounded-full font-medium text-base transition-all duration-300">
            <span className="inline-flex items-center gap-2">
              <Icon icon="solar:arrow-right-linear" className="text-lg" />
              Explore Features
            </span>
          </a>
        </motion.div>

        {/* Features Preview */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto"
        >
          {[
            { icon: "hugeicons:appointment-01", title: "Smart Appointments", desc: "Scheduling that works" },
            { icon: "solar:document-medicine-linear", title: "Patient Records", desc: "Secure digital files" },
            { icon: "solar:chart-2-linear", title: "Analytics", desc: "Real-time insights" },
            { icon: "mdi:heart-pulse", title: "Emergency Care", desc: "24/7 monitoring" },
          ].map((feature, index) => (
            <div key={index} className="bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="bg-blue-100 p-3 rounded-lg mb-3 w-fit mx-auto">
                <Icon icon={feature.icon} className="text-2xl text-blue-600" />
              </div>
              <h3 className="font-medium text-gray-900 mb-1">{feature.title}</h3>
              <p className="text-sm text-gray-600">{feature.desc}</p>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Animated Accents */}
      <motion.div
        animate={{ y: [0, -18, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-20 right-6 md:right-20 opacity-30"
      >
        <Icon icon="medical-icon:i-care-staff-area" className="text-5xl text-blue-400" />
      </motion.div>
      
      <motion.div
        animate={{ y: [0, 18, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-16 left-6 md:left-20 opacity-30"
      >
        <Icon icon="solar:health-linear" className="text-4xl text-cyan-400" />
      </motion.div>
    </section>
  );
}