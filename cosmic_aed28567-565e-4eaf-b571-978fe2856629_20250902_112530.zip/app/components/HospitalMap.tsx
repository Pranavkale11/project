"use client";

export default function HospitalMap() {
  return (
    <section className="py-20 bg-gray-50" id="location">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-6 text-center">Find Us</h2>
        <p className="text-gray-600 text-center mb-8">Wellnest Hospital, your trusted care partner.</p>
        <div className="rounded-2xl overflow-hidden shadow-lg border border-gray-200">
          <iframe
            title="Wellnest Location"
            src="https://www.google.com/maps?q=hospital&output=embed"
            className="w-full h-[380px]"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  );
}
