"use client";

import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import { useInView } from "framer-motion";
import { useRef } from "react";

export default function FeaturesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: "hugeicons:appointment-01",
      title: "Smart Appointment Scheduling",
      description: "AI-powered scheduling system that optimizes doctor availability and reduces wait times.",
      color: "from-blue-50 to-cyan-50"
    },
    {
      icon: "solar:document-medicine-linear",
      title: "Digital Patient Records",
      description: "Secure, comprehensive digital health records accessible to authorized medical staff instantly.",
      color: "from-cyan-50 to-sky-50"
    },
    {
      icon: "solar:heart-pulse-2-linear",
      title: "Real-time Monitoring",
      description: "Advanced patient monitoring with real-time alerts and automated emergency responses.",
      color: "from-teal-50 to-blue-50"
    },
    {
      icon: "solar:pills-3-linear",
      title: "Medication Management",
      description: "Track prescriptions, monitor drug interactions, and manage inventory efficiently.",
      color: "from-sky-50 to-cyan-50"
    },
    {
      icon: "solar:chart-2-linear",
      title: "Analytics & Insights",
      description: "Comprehensive analytics dashboard providing insights into hospital operations and patient outcomes.",
      color: "from-blue-50 to-teal-50"
    },
    {
      icon: "solar:shield-user-linear",
      title: "HIPAA Compliance",
      description: "Bank-level security ensuring patient data privacy and regulatory compliance.",
      color: "from-teal-50 to-sky-50"
    }
  ];

  return (
    <section id="features" ref={ref} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-gray-900 mb-6">
            Powerful Features for{" "}
            <span className="bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent font-medium">
              Modern Healthcare
            </span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our comprehensive hospital management platform provides everything you need to deliver 
            exceptional patient care while optimizing operational efficiency.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.8, delay: index * 0.08 }}
              className={`group relative rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 bg-gradient-to-br ${feature.color}`}
            >
              <div className="p-6">
                <div className="bg-blue-100 p-3 rounded-xl mb-4 w-fit">
                  <Icon icon={feature.icon} className="text-2xl text-blue-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
                <div className="mt-4 flex items-center text-blue-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  Learn more
                  <Icon icon="solar:arrow-right-linear" className="ml-2" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-16"
        >
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
            <h3 className="text-2xl font-medium text-gray-900 mb-4">
              Ready to Transform Your Healthcare Operations?
            </h3>
            <p className="text-gray-600 mb-6">
              Join hundreds of hospitals already using Wellnest to improve patient care and operational efficiency.
            </p>
            <a href="/dashboard" className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white px-8 py-4 rounded-full font-medium text-lg transition-all duration-300">
              Schedule a Demo
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}