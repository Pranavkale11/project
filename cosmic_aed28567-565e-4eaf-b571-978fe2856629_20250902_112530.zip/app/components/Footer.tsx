"use client";

import { Icon } from "@iconify/react";
import { motion } from "framer-motion";

export default function Footer() {
  const footerLinks = {
    "Product": [
      "Features", "Pricing", "Security", "Integrations", "API Documentation"
    ],
    "Solutions": [
      "Hospital Management", "Patient Care", "Emergency Response", "Analytics", "Compliance"
    ],
    "Resources": [
      "Documentation", "Help Center", "Community", "Blog", "Case Studies"
    ],
    "Company": [
      "About Us", "Careers", "Press", "Partners", "Contact"
    ]
  };

  const socialLinks = [
    { icon: "ri:twitter-x-fill", href: "#", label: "Twitter" },
    { icon: "ri:linkedin-fill", href: "#", label: "LinkedIn" },
    { icon: "ri:facebook-fill", href: "#", label: "Facebook" },
    { icon: "ri:github-fill", href: "#", label: "GitHub" },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-blue-500 p-2 rounded-xl">
                <Icon icon="mdi:hospital" className="text-white text-2xl" />
              </div>
              <span className="text-2xl font-semibold">Wellnest</span>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Revolutionizing healthcare management with cutting-edge technology. 
              Empowering hospitals to deliver exceptional patient care while optimizing operational efficiency.
            </p>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-gray-800 hover:bg-blue-600 p-2 rounded-lg transition-colors duration-200"
                  aria-label={social.label}
                >
                  <Icon icon={social.icon} className="text-xl" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Links Sections */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h3 className="font-medium text-lg mb-4">{title}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-gray-400 hover:text-white transition-colors duration-200 text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter Section */}
        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div className="mb-6 lg:mb-0">
              <h3 className="text-lg font-medium mb-2">Stay Updated</h3>
              <p className="text-gray-400">Get the latest healthcare technology news and product updates.</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 max-w-md">
              <input
                type="email"
                placeholder="Enter your email"
                className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent flex-1"
              />
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 whitespace-nowrap"
              >
                Subscribe
              </motion.button>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="text-gray-400 text-sm mb-4 md:mb-0">
            © 2024 Wellnest. All rights reserved.
          </div>
          
          <div className="flex flex-wrap gap-6 text-sm">
            <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
              Terms of Service
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
              HIPAA Compliance
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
              Security
            </a>
          </div>
        </div>
      </div>

      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute inset-0" 
             style={{
               backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
               backgroundSize: '60px 60px'
             }} 
        />
      </div>
    </footer>
  );
}